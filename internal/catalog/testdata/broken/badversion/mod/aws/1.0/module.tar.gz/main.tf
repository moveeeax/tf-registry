terraform {
  required_version = ">= 1.5.0"
}

# bad dir name
resource "null_resource" "mod" {
  triggers = {
    version = "1.0"
  }
}
