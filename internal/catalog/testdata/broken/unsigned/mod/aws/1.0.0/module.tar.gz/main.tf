terraform {
  required_version = ">= 1.5.0"
}

# no signature at all
resource "null_resource" "mod" {
  triggers = {
    version = "1.0.0"
  }
}
