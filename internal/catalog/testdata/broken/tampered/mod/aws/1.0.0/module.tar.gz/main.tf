terraform {
  required_version = ">= 1.5.0"
}

# signature belongs to another blob
resource "null_resource" "mod" {
  triggers = {
    version = "1.0.0"
  }
}
