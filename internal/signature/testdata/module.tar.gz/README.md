# terraform-aws-vpc

Opinionated AWS VPC with flow logs

Version 1.2.0.
