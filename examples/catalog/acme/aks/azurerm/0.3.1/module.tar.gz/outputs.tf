output "name" {
  description = "The name prefix that was applied."
  value       = var.name
}
