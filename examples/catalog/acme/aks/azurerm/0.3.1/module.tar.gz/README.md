# terraform-azurerm-aks

AKS cluster with workload identity

Version 0.3.1.
