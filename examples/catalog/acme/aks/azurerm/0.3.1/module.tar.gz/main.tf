terraform {
  required_version = ">= 1.5.0"
}

# AKS cluster with workload identity
resource "null_resource" "aks" {
  triggers = {
    version = "0.3.1"
  }
}
