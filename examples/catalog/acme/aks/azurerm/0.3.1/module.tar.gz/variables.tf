variable "name" {
  description = "Name prefix for created resources."
  type        = string
}
