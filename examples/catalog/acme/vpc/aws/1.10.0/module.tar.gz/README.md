# terraform-aws-vpc

Opinionated AWS VPC with flow logs

Version 1.10.0.
