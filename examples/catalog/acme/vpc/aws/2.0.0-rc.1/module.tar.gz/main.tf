terraform {
  required_version = ">= 1.5.0"
}

# Opinionated AWS VPC with flow logs
resource "null_resource" "vpc" {
  triggers = {
    version = "2.0.0-rc.1"
  }
}
