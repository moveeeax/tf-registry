# terraform-aws-vpc

Opinionated AWS VPC with flow logs

Version 2.0.0-rc.1.
