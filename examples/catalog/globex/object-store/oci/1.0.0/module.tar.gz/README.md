# terraform-oci-object-store

OCI object storage bucket

Version 1.0.0.
