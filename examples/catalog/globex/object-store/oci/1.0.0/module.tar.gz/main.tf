terraform {
  required_version = ">= 1.5.0"
}

# OCI object storage bucket
resource "null_resource" "object-store" {
  triggers = {
    version = "1.0.0"
  }
}
